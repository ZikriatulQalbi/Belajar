<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\PengaduanController;
use App\Http\Controllers\PermohonanController;

// Dashboard Route
Route::get('/', [DashboardController::class, 'index'])->name('dashboard');

// Pengaduan Routes
Route::resource('pengaduan', PengaduanController::class);

// Permohonan Routes
Route::resource('permohonan', PermohonanController::class);

Route::get('/menupengaduan', function () {
    return view('menupengaduan.index');
})->name('menupengaduan.index');
