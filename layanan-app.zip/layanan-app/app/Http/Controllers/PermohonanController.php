<?php

namespace App\Http\Controllers;

use App\Models\Permohonan;
use Illuminate\Http\Request;

class PermohonanController extends Controller
{
    public function index()
    {
        $permohonans = Permohonan::all();
        return view('permohonan.index', compact('permohonans'));
    }

    public function create()
    {
        return view('permohonan.create');
    }

    public function store(Request $request)
    {
        $request->validate([
            'instansi' => 'required',
            'jenis_aplikasi' => 'required',
            'deskripsi' => 'required',
        ]);

        Permohonan::create($request->all());
        return redirect()->route('permohonan.index')->with('success', 'Permohonan berhasil dibuat.');
    }

    public function show(Permohonan $permohonan)
    {
        return view('permohonan.show', compact('permohonan'));
    }
}
