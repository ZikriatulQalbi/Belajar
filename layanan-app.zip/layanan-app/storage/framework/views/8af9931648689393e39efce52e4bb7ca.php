

<?php $__env->startSection('title', 'Daftar Pengaduan'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container mt-4">
        <h4 class="mb-4">Daftar Pengaduan Jaringan</h4>
        <a href="<?php echo e(route('pengaduan.create')); ?>" class="btn btn-primary mb-3 bi bi-plus">Pengaduan</a>
        
        <table class="table table-striped table-bordered">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Instansi</th>
                    <th>Keluhan</th>
                    <th>Tanggal</th>
                    <th>Lampiran</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $pengaduans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pengaduan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($pengaduan->id); ?></td>
                        <td><?php echo e($pengaduan->instansi); ?></td>
                        <td><?php echo e($pengaduan->keluhan); ?></td>
                        <td><?php echo e($pengaduan->tanggal); ?></td>
                        <td><?php echo e($pengaduan->lampiran); ?></td>
                        <td>
                            <a href="<?php echo e(route('pengaduan.show', $pengaduan->id)); ?>" class="btn btn-info btn-sm">Lihat</a>
                            <a href="<?php echo e(route('pengaduan.edit', $pengaduan->id)); ?>" class="btn btn-warning btn-sm">Edit</a>
                            <form action="<?php echo e(route('pengaduan.destroy', $pengaduan->id)); ?>" method="POST"
                                style="display:inline;">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-danger btn-sm">Hapus</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\semester 5\layanan-app\resources\views/pengaduan/index.blade.php ENDPATH**/ ?>