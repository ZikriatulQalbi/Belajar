

<?php $__env->startSection('title', 'Daftar Permohonan'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container mt-4">
        <h3>Daftar Permohonan</h3>
        <a href="<?php echo e(route('permohonan.create')); ?>" class="btn btn-primary mb-3 bi bi-plus">Permohonan</a>
        <table class="table table-striped table-bordered">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Instansi</th>
                    <th>Jenis Aplikasi</th>
                    <th>Deskripsi</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $permohonans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permohonan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($permohonan->id); ?></td>
                        <td><?php echo e($permohonan->instansi); ?></td>
                        <td><?php echo e($permohonan->jenis_aplikasi); ?></td>
                        <td><?php echo e($permohonan->deskripsi); ?></td>
                        <td>
                            <a href="<?php echo e(route('permohonan.show', $permohonan->id)); ?>">Lihat</a>
                            <!-- Tambahkan aksi lain seperti edit dan delete -->
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\semester 5\layanan-app\resources\views/permohonan/index.blade.php ENDPATH**/ ?>