

<?php $__env->startSection('title', 'Buat Pengaduan'); ?>

<?php $__env->startSection('content'); ?>
    <h3 class="mb-4 text-center">Form Pengaduan Jaringan</h3>
    <form action="<?php echo e(route('pengaduan.store')); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>

        <div class="mb-3 mx-3">
            <label for="instansi" class="form-label">Instansi</label>
            <input type="text" id="instansi" name="instansi" class="form-control" required>
        </div>

        <div class="mb-3 mx-3">
            <label for="keluhan" class="form-label">Keluhan</label>
            <textarea id="keluhan" name="keluhan" class="form-control" rows="4" required></textarea>
        </div>

        <div class="mb-3 mx-3">
            <label for="tanggal" class="form-label">Tanggal</label>
            <input type="date" id="tanggal" name="tanggal" class="form-control" required>
        </div>

        <div class="mb-3 mx-3">
            <label for="foto" class="form-label">Lampiran Foto</label>
            <input type="file" id="foto" name="foto" class="form-control" accept="image/*">
        </div>


        <button type="submit" class="btn btn-primary mx-3">Kirim</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\semester 5\layanan-app\resources\views/pengaduan/create.blade.php ENDPATH**/ ?>