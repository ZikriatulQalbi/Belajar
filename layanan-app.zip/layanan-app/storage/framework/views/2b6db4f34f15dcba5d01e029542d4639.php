

<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>
    <h5 class="mx-3">DASHBOARD</h5>
    <div class="container">
        <div class="row">
            <div class="col-md-3 mb-3">
                <div class="card text-bg-info">
                    <div class="card-body text-center">
                        <i class="bi bi-person-lines-fill" style="font-size: 9rem; margin-bottom: -10px;"></i>
                        <a class="nav-link text-white" href="#">
                            <p class="card-text mx-4 "style="font-size: 1rem; line-height: 1.2;">Profil</p>
                        </a>
                    </div>

                </div>
            </div>

            <div class="col-md-3 mb-3">
                <div class="card text-bg-info">

                    <div class="card-body text-center">
                        <i class="bi bi-exclamation-circle" style="font-size: 9rem; margin-bottom: -10px;"></i>
                        <a class="nav-link text-white" href="/menupengaduan">
                            <p class="card-text mx-4 "style="font-size: 1rem;line-height: 1.2;">Pengaduan Jaringan</p>
                        </a>
                    </div>

                </div>
            </div>

            <div class="col-md-3 mb-3">
                <div class="card text-bg-info">
                    <div class="card-body text-center">
                        <i class="bi bi-journal-check" style="font-size: 8rem; margin-bottom: -10px;"></i>
                        <a class="nav-link text-white" href="/permohonan">
                            <p class="card-text mx-4" style="font-size: 1rem; line-height: 1.2;">Permohonan Pembuatan
                                Aplikasi
                            </p>
                        </a>
                    </div>
                </div>
            </div>


            <div class="col-md-3 mb-3">
                <div class="card text-bg-info">
                    <div class="card-body text-center">
                        <i class="bi bi-clock-history" style="font-size: 9rem; margin-bottom: -10px;"></i>
                        <a class="nav-link text-white" href="#">
                            <p class="card-text mx-4 "style="font-size: 1rem; line-height: 1.2;">History</p>
                        </a>
                    </div>

                </div>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\semester 5\layanan-app\resources\views/dashboard.blade.php ENDPATH**/ ?>