

<?php $__env->startSection('title', 'Detail Pengaduan'); ?>

<?php $__env->startSection('content'); ?>
    <h3 class="mx-3">Detail Pengaduan</h3>
    <p class="mx-3">Instansi: <?php echo e($pengaduan->instansi); ?></p>
    <p class="mx-3">Keluhan: <?php echo e($pengaduan->keluhan); ?></p>
    <!-- Tambahkan tombol edit dan delete jika diperlukan -->
    <a class="mx-3" href="/pengaduan">Kembali</a>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\semester 5\layanan-app\resources\views/pengaduan/show.blade.php ENDPATH**/ ?>