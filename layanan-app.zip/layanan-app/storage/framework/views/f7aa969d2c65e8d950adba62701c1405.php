

<?php $__env->startSection('title', 'Buat Permohonan'); ?>

<?php $__env->startSection('content'); ?>
    <h1>Buat Permohonan Baru</h1>
    <form action="<?php echo e(route('permohonan.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div>
            <label for="instansi">Instansi</label>
            <input type="text" id="instansi" name="instansi" required>
        </div>
        <div>
            <label for="jenis_aplikasi">Jenis Aplikasi</label>
            <input type="text" id="jenis_aplikasi" name="jenis_aplikasi" required>
        </div>
        <div>
            <label for="deskripsi">Deskripsi</label>
            <textarea id="deskripsi" name="deskripsi" required></textarea>
        </div>
        <button type="submit">Kirim</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\semester 5\layanan-app\resources\views/permohonan/create.blade.php ENDPATH**/ ?>