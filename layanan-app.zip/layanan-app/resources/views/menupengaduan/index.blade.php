@extends('layouts.app')

@section('title', 'Pilihan')

@section('content')
    <div class="container">
        <div class="row">
            <div class="col-md-3 mb-3">
                <div class="card text-bg-info">
                    <div class="card-body text-center">
                        <i class="bi bi-person-lines-fill" style="font-size: 9rem; margin-bottom: -10px;"></i>
                        <a class="nav-link text-white" href="/pengaduan">
                            <p class="card-text mx-4 "style="font-size: 1rem; line-height: 1.2;">Menu Pengajuan</p>
                        </a>
                    </div>

                </div>
            </div>

            <div class="col-md-3 mb-3">
                <div class="card text-bg-info">

                    <div class="card-body text-center">
                        <i class="bi bi-cpu-fill" style="font-size: 9rem; margin-bottom: -10px;"></i>
                        <a class="nav-link text-white" href="/pengaduan">
                            <p class="card-text mx-4 "style="font-size: 1rem;line-height: 1.2;">Menu Proses</p>
                        </a>
                    </div>

                </div>
            </div>
        </div>
    </div>




@endsection
