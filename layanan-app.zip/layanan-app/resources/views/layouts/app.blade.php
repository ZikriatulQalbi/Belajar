<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>@yield('title')</title>
    <link rel="stylesheet" href="/bootstrap/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css">
    <style>
        .profile-icon {
            width: 20px;
            height: 20px;
            border-radius: 20%;
            object-fit: cover;
            margin-bottom: 10px;
        }

        .sidebar-divider {
            border-bottom: 1px solid #ffffff;
            margin: 20px 0;
        }

        /* Menambahkan overflow auto agar main content tidak keluar */
        .main-content {
            overflow: auto;
        }
    </style>
</head>

<body>

    <div class="d-flex">
        <!-- Sidebar -->
        <nav class="bg-dark text-white p-3" style="min-width: 250px; height: 100vh;">
            <!-- Bagian Atas -->
            <div class="text-center mb-4">
                <img src="/images/atul.jpg" alt="Profile" class="profile-icon">
                <h5>Nama Pengguna</h5>
            </div>
            <ul class="nav flex-column mb-4">
                <li class="nav-item mb-2">
                    <a class="nav-link text-white" href="/dashboard">
                        <i class="bi bi-speedometer2"></i> Dashboard
                    </a>
                </li>
            </ul>

            <!-- Divider -->
            <div class="sidebar-divider"></div>

            <!-- Menu Utama -->
            <h6 class="text-uppercase">Menu Utama</h6>
            <ul class="nav flex-column">
                <li class="nav-item mb-2">
                    <a class="nav-link text-white" href="/pengaduan">
                        <i class="bi bi-exclamation-circle"></i> Pengaduan
                    </a>
                </li>
                <li class="nav-item mb-2">
                    <a class="nav-link text-white" href="/permohonan">
                        <i class="bi bi-journal-check"></i> Permohonan
                    </a>
                </li>
                <li class="nav-item mb-2">
                    <a class="nav-link text-white" href="/histori">
                        <i class="bi bi-clock-history"></i> Histori
                    </a>
                </li>
            </ul>
        </nav>

        <!-- Main Content -->
        <div class="flex-grow-1  main-content">
            <nav class="navbar navbar-expand-lg mb-4" style="background-color: #007bff;">
                <div class="container-fluid">
                    <a class="navbar-brand text-white" href="#">
                        <span class="navbar-toggler-icon"></span>

                    </a>
                    <h5 class="mb-0 ms-2 text-white">SISTEM LAYANAN PENGADUAN DAN PERMOHONAN APPLIKASI OPD </h5>
                    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
                        aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                    </button>



                    <div class="collapse navbar-collapse" id="navbarNav">
                        <ul class="navbar-nav ms-auto">
                            <li class="nav-item">
                                <a class="nav-link text-white" href="#">
                                    <i class="bi bi-person-circle"></i>
                                </a>
                            </li>

                        </ul>
                    </div>
                </div>
            </nav>

            @yield('content')
        </div>
    </div>

    <footer class="bg-dark text-white text-center py-2 mt-4">
        Copyright {{ date('Y') }} &copy; by Teknologi Informasi
    </footer>

    <script src="/bootstrap/bootstrap.bundle.min.js"></script>
</body>

</html>
