@extends('layouts.app')

@section('title', 'Detail Pengaduan')

@section('content')
    <h3 class="mx-3">Detail Pengaduan</h3>
    <p class="mx-3">Instansi: {{ $pengaduan->instansi }}</p>
    <p class="mx-3">Keluhan: {{ $pengaduan->keluhan }}</p>
    <!-- Tambahkan tombol edit dan delete jika diperlukan -->
    <a class="mx-3" href="/pengaduan">Kembali</a>
@endsection
