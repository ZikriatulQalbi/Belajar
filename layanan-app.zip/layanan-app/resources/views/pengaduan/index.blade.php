@extends('layouts.app')

@section('title', 'Daftar Pengaduan')

@section('content')
    <div class="container mt-4">
        <h4 class="mb-4">Daftar Pengaduan Jaringan</h4>
        <a href="{{ route('pengaduan.create') }}" class="btn btn-primary mb-3 bi bi-plus">Pengaduan</a>
        
        <table class="table table-striped table-bordered">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Instansi</th>
                    <th>Keluhan</th>
                    <th>Tanggal</th>
                    <th>Lampiran</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($pengaduans as $pengaduan)
                    <tr>
                        <td>{{ $pengaduan->id }}</td>
                        <td>{{ $pengaduan->instansi }}</td>
                        <td>{{ $pengaduan->keluhan }}</td>
                        <td>{{ $pengaduan->tanggal }}</td>
                        <td>{{ $pengaduan->lampiran }}</td>
                        <td>
                            <a href="{{ route('pengaduan.show', $pengaduan->id) }}" class="btn btn-info btn-sm">Lihat</a>
                            <a href="{{ route('pengaduan.edit', $pengaduan->id) }}" class="btn btn-warning btn-sm">Edit</a>
                            <form action="{{ route('pengaduan.destroy', $pengaduan->id) }}" method="POST"
                                style="display:inline;">
                                @csrf
                                @method('DELETE')
                                <button type="submit" class="btn btn-danger btn-sm">Hapus</button>
                            </form>
                        </td>
                    </tr>
                @endforeach
            </tbody>
        </table>
    </div>
@endsection
