@extends('layouts.app')

@section('title', 'Daftar Permohonan')

@section('content')
    <div class="container mt-4">
        <h3>Daftar Permohonan</h3>
        <a href="{{ route('permohonan.create') }}" class="btn btn-primary mb-3 bi bi-plus">Permohonan</a>
        <table class="table table-striped table-bordered">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Instansi</th>
                    <th>Jenis Aplikasi</th>
                    <th>Deskripsi</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($permohonans as $permohonan)
                    <tr>
                        <td>{{ $permohonan->id }}</td>
                        <td>{{ $permohonan->instansi }}</td>
                        <td>{{ $permohonan->jenis_aplikasi }}</td>
                        <td>{{ $permohonan->deskripsi }}</td>
                        <td>
                            <a href="{{ route('permohonan.show', $permohonan->id) }}">Lihat</a>
                            <!-- Tambahkan aksi lain seperti edit dan delete -->
                        </td>
                    </tr>
                @endforeach
            </tbody>
        </table>

    </div>
@endsection
