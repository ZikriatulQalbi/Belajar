@extends('layouts.app')

@section('title', 'Buat Permohonan')

@section('content')
    <h1>Buat Permohonan Baru</h1>
    <form action="{{ route('permohonan.store') }}" method="POST">
        @csrf
        <div>
            <label for="instansi">Instansi</label>
            <input type="text" id="instansi" name="instansi" required>
        </div>
        <div>
            <label for="jenis_aplikasi">Jenis Aplikasi</label>
            <input type="text" id="jenis_aplikasi" name="jenis_aplikasi" required>
        </div>
        <div>
            <label for="deskripsi">Deskripsi</label>
            <textarea id="deskripsi" name="deskripsi" required></textarea>
        </div>
        <button type="submit">Kirim</button>
    </form>
@endsection
