@extends('layouts.app')

@section('title', 'Detail Permohonan')

@section('content')
    <h1>Detail Permohonan</h1>
    <p>Instansi: {{ $permohonan->instansi }}</p>
    <p>Jenis Aplikasi: {{ $permohonan->jenis_aplikasi }}</p>
    <p>Deskripsi: {{ $permohonan->deskripsi }}</p>
    <!-- Tambahkan tombol edit dan delete jika diperlukan -->
@endsection
