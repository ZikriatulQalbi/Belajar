<?php $__env->startSection('title', 'Data Movie'); ?>

<?php $__env->startSection('content'); ?>

<h1>Data Master Movie</h1>
<a href="/movies/create" class="btn btn-danger">Input New Movie</a>
<table class="table table-hover">
    <thead>
      <tr>
        <th scope="col">No</th>
        <th scope="col">Judul</th>
        <th scope="col">Kategori</th>
        <th scope="col">Tahun</th>
        <th scope="col">Pemain</th>
        <th scope="col">Aksi</th>
      </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $movies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $movie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <th scope="row"><?php echo e($loop->iteration); ?></th>
            <td><?php echo e($movie->judul); ?></td>
            <td><?php echo e($movie->category->nama_kategori); ?></td>
            <td><?php echo e($movie->tahun); ?></td>
            <td><?php echo e($movie->pemain); ?></td>
            <td class="text-nowrap">
                <a href="/movie/<?php echo e($movie['id']); ?>/edit" class="btn btn-warning">Edit</a>
                <a href="/movie/delete/<?php echo e($movie->id); ?>" class="btn btn-danger" onclick="return confirm('Apakah Anda yakin ingin menghapus data ini?')">Hapus</a>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>
    <div class="d-flex justify-content-center">
        <?php echo e($movies->links()); ?>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\semester 3\web_lanjut\laravel-movie\laravel-movie\resources\views/data-movies.blade.php ENDPATH**/ ?>